/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* CIC Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2015                                          */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */
var helper =require('./helper');
var config =require('./config');
var utils =require('./utils');
var Services = function(app) {
	var tokenSplitStr='||';
	//remote login
	app.post('/api/login', function (req, res) {
		var userid=req.body.userid;
		var password=req.body.password;
		var isIMC = config.ibmer_host.match(/(lmc)|(wecm)/i);
		var path='/api/ibmer/login';
		var header=null;
		if(isIMC){
			path='/ems'+path;
			header=helper.createHeader(userid,password);
		}
		helper.httpsRequest(config.ibmer_host,config.ibmer_port,path,
			{userid:userid,password:password},{isTLSv1:true},function(result){
			var objResult=result;
			if (!utils.isNullOrUndefined(result)) {
	           try {
	              objResult = JSON.parse(result.toString());
	           } catch(e) {//do nothing
	           }
	        }
			if(objResult.isSuccessful){
				req.session.user_id = userid;
			    req.session.password = password;
			}
			res.send(result);
		},'POST', header, !isIMC);
	});
	app.get('/api/logout', function (req, res) {
		req.session.user_id = null;
		req.session.password = null;
		res.redirect('/');
	});
	app.get('/api/image/:userId/:imgSize', function (req, res) {
		var userId = req.params.userId;
	    var imgSize = req.params.imgSize;
	    
	    var isIMC = config.ibmer_host.match(/(lmc)|(wecm)/i);
		var path='/api/faces/image';
		var header=null;
		if(isIMC){
			path='/ems'+path;
			var token=req.query.token;
			if(!utils.isNullOrUndefined(req.session.user_id)){
				header=helper.createHeader(req.session.user_id,req.session.password);
			}else if(!utils.isNullOrUndefined(token)){
				var tokenStr=helper.decodeToken(token);
				var tokenArr=tokenStr.split(tokenSplitStr);
				header=helper.createHeader(tokenArr[0],tokenArr[1]);
			}else{
				res.writeHead(200, {'Content-Type': 'text/json'});
				res.end(JSON.stringify(helper.getErrorObject("Invalid request without user credentials!")));
				return;
			}
		}
		//encodeURIComponent
		path=path+"/"+userId+"/"+imgSize;
		res.writeHead(200, {'Content-Type': 'image/png'});
		helper.httpsRequest4Stream(config.ibmer_host,config.ibmer_port,path,null,{isTLSv1:true},function(err){
			console.log(err);
		},'GET', header, !isIMC,res);
	});
};
module.exports = Services;