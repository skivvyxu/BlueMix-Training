/**
 * helper.js is used for capsulating json object included message need return and some other common functions 
 * such as get content by http/https request
 * @author Jacky
 */
var crypto = require('crypto');
var https = require('https');
var http = require('http');
var utils = require('./utils');
var config = require('./config');
var querystring=require('querystring');
//TOKEN CRYPT_KEY
var PASSWORD_CRYPT_KEY = 'token4@ibm';

/**
 * format date
 * @param fmt date format
 * @returns
 */
Date.prototype.format = function (fmt) {
    var o = {
        'M+': this.getMonth() + 1,
        'd+': this.getDate(),
        'h+': this.getHours(),
        'm+': this.getMinutes(),
        's+': this.getSeconds(),
        'q+': Math.floor((this.getMonth() + 3) / 3),
        'S': this.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
      if (new RegExp('(' + k + ')').test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]): (('00' + o[k]).substr(('' + o[k]).length)));
      }
    }
    return fmt;
};

/**
 * trim the string 
 */
String.prototype.trim = function () {
  return this.replace(/(^\s*)|(\s*$)/g, '');
};

/**
 * format TZ time the string such as 2014-07-25T16:15:29Z
 */
String.prototype.formatTZTime = function () {
  return this.substring(0, 10) + ' '+this.substring(11, 16);
};

/**
 * define return object
 * @isSuccessful flag to judge if rest calling done successfully
 * @message message such a invalid input
 * @error error message such as exception or system error
 * @statusCode status code such as for http response code
 * @data data returned when isSuccessful is true
 */
function ReturnObject(isSuccessful, message, error, statusCode, data) {
  if (!utils.isNullOrUndefined(isSuccessful)) {
    this.isSuccessful = isSuccessful;
  }
  if (!utils.isNullOrUndefined(message)) {
    if ((utils.isString(message) && message.trim() !== '') || !utils.isString(message)) {
      this.message = message;
    }
  }
  if (!utils.isNullOrUndefined(error)) {
    if ((utils.isString(error) && error.trim() !== '') || !utils.isString(error)) {
      this.error = error;
    }
  }
  if (!utils.isNullOrUndefined(data)) {
    this.data = data;
  }
  if (!utils.isNullOrUndefined(statusCode)) {
    this.statusCode = statusCode;
  }
}

/**
 * get return object
 * @isSuccessful flag to judge if rest calling done successfully
 * @message message such a invalid input
 * @error error such as exception or system error
 * @data data returned when isSuccessful is true
 */
exports.getReturnObject = function(isSuccessful, message, error, data) {
  return new ReturnObject(isSuccessful, message, error, data);
};

/**
 * create message object by parameters
 * @param isSuccessful flag to judge if rest calling done successfully
 * @param message message info need return
 */
exports.getMessageObject = function(isSuccessful, message) {
  return this.getReturnObject(isSuccessful, message);
};

/**
 * create error object by parameters
 * @param error error message info need return
 */
exports.getErrorObject = function(error, statusCode){
  return this.getReturnObject(false, null, error, statusCode);
};

/**
 * create data object by parameters
 * @param data data object info need return
 */
exports.getDataObject = function(data){
  return this.getReturnObject(true, null, null, null, data);
};

/**
 * created query object by params
 * @param queryResult json object included data of db table
 * @param isList flag to judge if one record or multi-records 
 */
exports.getResult = function(queryResult, isList) {
  if (isList) {
    return {'list': queryResult, 'isSuccessful': true};
  } else {
    return {'entity': queryResult, 'isSuccessful': true};
  }
};

/**
 * encode plainText with cipher lib
 * @param plainText source string need encode
 */
exports.encodeToken = function(plainText) {
  var cipher = crypto.createCipher('aes-256-cbc', PASSWORD_CRYPT_KEY);
  var crypted = cipher.update(plainText, 'binary', 'hex');
  crypted += cipher.final('hex');
  return crypted;
};

/**
 * decode source string with cipher lib
 * @param encodeText string need decode
 * @param callback need do action if err happened 
 */
exports.decodeToken = function(encodeText, callback) {
  try {
    var decipher = crypto.createDecipher('aes-256-cbc', PASSWORD_CRYPT_KEY);
    var plainText = decipher.update(encodeText, 'hex', 'binary');
    plainText += decipher.final('binary');
    return plainText;
  } catch (err) {
    //handle error
    callback(this.getErrorObject(err));
    return null;
  }
};

/**
 * get included string for begin char to end char
 * @param inputStr input string
 * @param beginChar beginning char
 * @param endChar end char
 */
exports.getIncludeString = function(inputStr, beginChar, endChar) {
  var beginIndex = inputStr.indexOf(beginChar);
  var endIndex = inputStr.indexOf(endChar);
  return inputStr.substring(beginIndex + 1, endIndex);
};

/**
 * submit http request by get
 * @param url http request URL
 * @param data JSON data for post, for example:var data = {userName: 'alityns@us.ibm.com'};
 * @param callback function
 */
exports.httpGet = function(url, data, callback) {
  var that = this;
  var params = null;
  if (!utils.isNullOrUndefined(data)) {
    params = querystring.stringify(data);
  }
  var req = http.request(url, function(res) {
    res.setEncoding('utf-8');
    var data = [];
    var dataLen = 0;
    res.on('data', function(chunk) {
      data.push(chunk);
      dataLen += chunk.length;
    });
    res.on('end', function() {
      var buf = '';
      for (var i = 0, len = data.length, pos=0; i<len; i++) {
        buf += data[i].toString();
        pos += data[i].length;
      }
      if (callback) {
        if (res.statusCode===200) {
          callback(buf);
        }else{
          callback(that.getErrorObject(buf, res.statusCode));
        }
      }
    });
  });
  if (params !== null ) {
    req.write(params);
  }
  req.end();
  req.on('error', function(err) {
    if (callback) {
      callback(that.getErrorObject(err));
    }
  });
};

/**
 * submit http request and get page data
 * @param host http host name, for example:iscid01.usil.ibm.com
 * @param port http port, for example:80
 * @param path URL path, for example:/SALES_SUPP/jaxrs/sales/opportunities/
 * @param data JSON data for post, for example:var data = {userName: 'alityns@us.ibm.com'};
 * @param callback function
 * @param method http method:GET or POST
 */
exports.httpRequest = function(host, port, path, data, callback, method) {
  var that = this;
  var params = null;
  var headers=null;
  headers={
    'Content-Type': 'application/x-www-form-urlencoded'
  };
  if (!utils.isNullOrUndefined(data)) {
    params = querystring.stringify(data);
  }
  var options = {
    hostname: host,
    port: port,
    path: path,
    method: method,
    rejectUnauthorized: false,
    headers: headers
  };
  var req = http.request(options, function(res) {
    res.setEncoding('utf-8');
    var data = []; 
    var dataLen = 0;
    res.on('data', function(chunk) {
      data.push(chunk);
      dataLen += chunk.length;
    });
    res.on('end', function() {
      var buf = '';
      for (var i = 0, len = data.length, pos = 0; i < len; i++) {
        buf += data[i].toString();
        pos += data[i].length;
      }
      if (callback) {
        if (res.statusCode===200) {
          callback(buf);
        } else {
          callback(that.getErrorObject(buf, res.statusCode));
        }
      }
    });  
  });
  req.on('socket', function (socket) {
      socket.setTimeout(config.timeout);  
      socket.on('timeout', function() {
        console.log("Error:timeout had happened!");
        req.abort();
      });
  });  
  if (params !== null) {
	req.write(params);
  }
  req.end();
  req.on('error', function(err) {
    if (callback) {
      callback(that.getErrorObject(err));
    }
  });
};

/**
 * submit https request and get page data
 * @param host https host name, for example:iscid01.usil.ibm.com
 * @param port https port, for example:443
 * @param path URL path, for example:/SALES_SUPP/jaxrs/sales/opportunities/
 * @param data JSON data for post, for example:var data = {userName: 'alityns@us.ibm.com'};
 * @param callback function
 * @param secure{isSSLv3: if use SSL V3 secure protocol,isTLSv1: if use TLS v1 secure protocol}
 * @param method https method:GET or POST
 * @param header request header like {'Content-Type': 'application/x-www-form-urlencoded'}
 * @param queryStringFlag flag indicate param type 
 *     if 'name=sword&pass=ok' it should be true.
 *     if '{name:'sword',pass:'ok'}' it should be false. 
 */
exports.httpsRequest = function(host, port, path, data, secure, callback, method, header, queryStringFlag) {
  var url = host + ':' + port + path;
  var that = this;
  var params = null;
  if (utils.isNullOrUndefined(header)) {
    header = {
      'Content-Type': 'application/x-www-form-urlencoded'
    };
  }
  if (!utils.isNullOrUndefined(data)) {
    if (queryStringFlag) {
      params = querystring.stringify(data);
    } else {
      params = JSON.stringify(data);
    }
  }
  //console.log(params);
  var options = {
    hostname: host,
    port: port,
    path: path,
    method: method,
    rejectUnauthorized: false,
    headers: header
  };
  if (secure && secure.isSSLv3) {
    options.secureProtocol = 'SSLv3_method';
  }else if (secure && secure.isTLSv1) {
    options.secureProtocol = 'TLSv1_method';
  }
  var beginTime = new Date();
  var endTime = null;
  var req = https.request(options, function(res) {
    res.setEncoding('utf-8');
    var data = [];
    var dataLen = 0;
    res.on('data', function(chunk) {
      data.push(chunk);
      dataLen += chunk.length;
    });
    res.on('end', function() {
      var buf = '';
      for (var i = 0, len = data.length, pos = 0; i < len; i++) {
        buf += data[i].toString();
        pos += data[i].length;
      }
      endTime = new Date();
      console.log('STATUS: ' + res.statusCode +' for '+ url);
      console.log('BEGIN:' + beginTime.format('yyyy-MM-dd hh:mm:ss') + ',END:' + 
        endTime.format('yyyy-MM-dd hh:mm:ss') + ',Time Cost(s):' + 
        (endTime.getTime() - beginTime.getTime())/1000);

      if (callback) {
        if (res.statusCode === 200) {
          callback(buf);
        } else {
          callback(that.getErrorObject(buf, res.statusCode));
        }
      }
    });
  });
  req.on('socket', function (socket) {
      socket.setTimeout(config.timeout);  
      socket.on('timeout', function() {
        console.log("Error:timeout had happened!");
        req.abort();
      });
  });   
  if (params !== null){
    req.write(params);
  }
  req.end();
  req.on('error', function(err) {
    if (callback) {
      console.log(err);
      callback(that.getErrorObject(err));
    }
  });
};

/**
 * submit https request and get page data
 * @param host https host name, for example:iscid01.usil.ibm.com
 * @param port https port, for example:443
 * @param path URL path, for example:/SALES_SUPP/jaxrs/sales/opportunities/
 * @param data JSON data for post, for example:var data = {userName: 'alityns@us.ibm.com'};
 * @param callback function
 * @param secure{isSSLv3: if use SSL V3 secure protocol,isTLSv1: if use TLS v1 secure protocol}
 * @param method https method:GET or POST
 * @param header request header like {'Content-Type': 'application/x-www-form-urlencoded'}
 * @param queryStringFlag flag indicate param type 
 *     if 'name=sword&pass=ok' it should be true.
 *     if '{name:'sword',pass:'ok'}' it should be false. 
 */
exports.httpsRequest4Stream = function(host, port, path, data, secure, callback, method, header, queryStringFlag, response) {
  var url = host + ':' + port + path;
  var that = this;
  var params = null;
  if (utils.isNullOrUndefined(header)) {
    header = {
      'Content-Type': 'application/x-www-form-urlencoded'
    };
  }
  if (!utils.isNullOrUndefined(data)) {
    if (queryStringFlag) {
      params = querystring.stringify(data);
    } else {
      params = JSON.stringify(data);
    }
  }
  //console.log(params);
  var options = {
    hostname: host,
    port: port,
    path: path,
    method: method,
    rejectUnauthorized: false,
    headers: header
  };
  if (secure && secure.isSSLv3) {
    options.secureProtocol = 'SSLv3_method';
  }else if (secure && secure.isTLSv1) {
    options.secureProtocol = 'TLSv1_method';
  }
  var beginTime = new Date();
  var endTime = null;
  var req = https.request(options, function(res) {
    res.on('data', function(chunk) {
      response.write(chunk);
    });
    res.on('end', function() {
      response.end();
    });
  });
  req.on('socket', function (socket) {
      socket.setTimeout(config.timeout);  
      socket.on('timeout', function() {
        console.log("Error:timeout had happened!");
        req.abort();
      });
  });   
  if (params !== null){
    req.write(params);
  }
  req.end();
  req.on('error', function(err) {
    if (callback) {
      console.log(err);
      callback(that.getErrorObject(err));
    }
  });
};

/**
 * submit http request and get page data by GET
 * @param host http host name, for example:iscid01.usil.ibm.com
 * @param port http port, for example:80
 * @param path URL path, for example:/SALES_SUPP/jaxrs/sales/opportunities/
 * @param callback function
 */
exports.getHttpRequest = function(host, port, path, callback) {
  this.httpRequest(host, port, path, null, callback, 'GET');
};

/**
 * submit http request and get page data by POST
 * @param host http host name, for example:iscid01.usil.ibm.com
 * @param port http port, for example:80
 * @param path URL path, for example:/SALES_SUPP/jaxrs/sales/opportunities/
 * @param data JSON data for post, for example:var data = {userName: 'alityns@us.ibm.com'};
 * @param callback function
 */
exports.postHttpRequest = function(host, port, path, data, callback) {
  this.httpRequest(host, port, path, data, callback, 'POST');
};

/**
 * submit https request and get page data by GET
 * @param host https host name, for example:iscid01.usil.ibm.com
 * @param port https port, for example:443
 * @param path URL path, for example:/SALES_SUPP/jaxrs/sales/opportunities/
 * @param callback function
 */
exports.getHttpsRequest = function(host, port, path, callback) {
  this.httpsRequest(host, port, path, null, {isTLSv1:true}, callback, 'GET', null, true);
};

/**
 * submit https request and get page data by POST
 * @param host https host name, for example:iscid01.usil.ibm.com
 * @param port https port, for example:443
 * @param path URL path, for example:/SALES_SUPP/jaxrs/sales/opportunities/
 * @param data JSON data for post, for example:var data = {userName: 'alityns@us.ibm.com'};
 * @param callback function
 */
exports.postHttpsRequest = function(host, port, path, data, callback) {
  this.httpsRequest(host, port, path, data, {isTLSv1:true}, callback, 'POST', null, true);
};

/**
 * create header to Basic authentication
 */
exports.createHeader = function(id, password) {
  return {
	'Content-Type': 'application/json',
	'Authorization': 'Basic ' + new Buffer(id + ':' + password).toString('base64')
  };
};