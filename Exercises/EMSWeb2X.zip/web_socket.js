/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* CIC Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2015                                          */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */
var WebSocket = function(io,socket) {
	socket.on('comment', function(msgObj){
		//console.log(msgObj);
		io.emit('messages', msgObj);//To all including self
		//socket.broadcast.emit('messages',msgObj);//To all excluding self
	});
	socket.on('disconnect', function(){
		console.log('User disconnected');
	});
	socket.on('login',function(userObj){
		io.emit('messages', userObj);
	});
};
module.exports = WebSocket;