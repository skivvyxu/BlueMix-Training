/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* CIC Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2015                                          */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */
var express = require('express');
var https = require('https');
var http = require('http');
var bodyParser = require('body-parser');
var session = require('express-session');
var File = require('./file').File;
/********************************Common libs******************************************/
//config message/commands
var enableLog4j = (process.env.ENABLE_LOG4J || false);
var isBluemix = (process.env.ENV_BLUEMIX || false);

console.log('ENV_BLUEMIX', isBluemix, 'ENABLE_LOG4J', enableLog4j)
/********************************Catch Global exception that is unexpected******************************************/
process.on('uncaughtException', function (err, a, b) {
	console.log('Caught Uncaught exception: ', err);
	console.log('stack trace', err.stack);
});


/********************************Start Application******************************************/
/**
 * App settings.
 */
var port = (process.env.VCAP_APP_PORT || 8080);
var ports = (process.env.VCAP_APP_PORTS || 1443);
var host = (process.env.VCAP_APP_HOST || 'localhost');
var app = express();
app.use(session({secret: 'keyboardcat',resave:true,saveUninitialized:true}));
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); //for parsing application/x-www-form-urlencoded
var httpServer = http.createServer(app);
var sio = require('socket.io');
//var io = new sio({'transports': [ 'websocket', 'flashsocket', 'htmlfile', 'xhr-polling', 'jsonp-polling']});
var httpServers = null;

if (!isBluemix) {
	var securityOptions ={
        key: File.readSync(__dirname+'/cert/ibmerservices.key'),
        cert: File.readSync(__dirname+'/cert/ibmerservices.crt')
	};
	httpServers = https.createServer(securityOptions, app);
	io=sio(httpServers);
	httpServers.listen(ports, function () {
		 console.log('app listening on https:' + ports);
	});
}else{
	io=sio(httpServer);
}

httpServer.listen(port, function(){
	console.log('app listening on http:' + port);
});

//Apply the log4j if any
if (enableLog4j) {
	var logLevel = (process.env.LOG_LEVEL || 'INFO');//FATAL, ERROR, WARN, INFO, DEBUG, TRACE
	var logjs = require('./logger').logjs.getInstance();
	//write access logs into access.log
	var logAccess = logjs.getLogger('access');
	app.use(logjs.connectLogger(logAccess, {level: 'auto'}));
	var logConsole = logjs.getLogger('console');
	logConsole.setLevel(logLevel);
}

/**
 * General configuration.
 */
//app.use('/public', express.static(__dirname + '/public'));
app.use(express.static(__dirname + '/public')); //setup static public directory
/********************************Initialize Data******************************************/
// only HTTPS supported if any
// Enable reverse proxy support in Express. This causes the
//the "X-Forwarded-Proto" header field to be trusted so its
//value can be used to determine the protocol. See 
//http://expressjs.com/api#app-settings for more details.
app.enable('trust proxy');
//Add a handler to inspect the req.secure flag (see 
//http://expressjs.com/api#req.secure). This allows us 
//to know whether the request was via http or https.
app.use(function (req, res, next) {
	if (req.secure) {
		// request was via https, so do no special handling
		next();
	} else {
		// request was via http, so redirect to https
		res.redirect('https://' + req.headers.host + req.url);
	}
});

app.get('/', function (req, res) {
	var contentPath = __dirname + '/views/index.html';
	res.sendFile(contentPath);
});

require('./services')(app);

io.sockets.on('connection', function (socket) {
	console.log('An user connected');
	console.log('connection, socket id: ', socket.id);
	//io.emit('messages', 'Welcome to join!');//to all including self
	require('./web_socket')(io,socket);
});