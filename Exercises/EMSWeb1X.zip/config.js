/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* CIC Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2015                                          */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */                                   
/* ***************************************************************** */
//Configuration parameters 
module.exports = {
	ibmer_host : 'wecm.ibm.com',
    ibmer_port : 15011,
    ibmer_uri  : 'https://wecm.ibm.com:15011',
    timeout: 60000
};

//module.exports = {
//	ibmer_host : 'ibmerservices.w3ibm.mybluemix.net',
//    ibmer_port : 443,
//    ibmer_uri  : 'https://ibmerservices.w3ibm.mybluemix.net',
//    timeout: 60000
//};